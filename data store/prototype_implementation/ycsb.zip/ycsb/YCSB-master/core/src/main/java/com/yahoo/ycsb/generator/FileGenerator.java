/**                                                                                                                                                                                
 * Licensed under the Apache License, Version 2.0 (the "License"); you                                                                                                             
 * may not use this file except in compliance with the License. You                                                                                                                
 * may obtain a copy of the License at                                                                                                                                             
 *                                                                                                                                                                                 
 * http://www.apache.org/licenses/LICENSE-2.0                                                                                                                                      
 *                                                                                                                                                                                 
 * Unless required by applicable law or agreed to in writing, software                                                                                                             
 * distributed under the License is distributed on an "AS IS" BASIS,                                                                                                               
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or                                                                                                                 
 * implied. See the License for the specific language governing                                                                                                                    
 * permissions and limitations under the License. See accompanying                                                                                                                 
 * LICENSE file.                                                                                                                                                                   
 */

package com.yahoo.ycsb.generator;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import com.yahoo.ycsb.Client;
import java.io.DataOutputStream;	
import java.net.Socket;
/**
 * A generator, whose sequence is the lines of a file.
 */
public class FileGenerator extends Generator
{
	String[] filename;
	String current;
	BufferedReader reader;
        HashMap<String,Long> hash_key;
	long current_key;
	String current_file;
	int file_index;
        int thread_index;
        BufferedReader reader_ramsize;
	public static int ramsize;

	/**
	 * Create a FileGenerator with the given file.
	 * @param _filename The file to read lines from.
	 */
	public FileGenerator(String _filename)
	{
/*
		try {
			filename = _filename;
			File file = new File(filename);
			FileInputStream in = new FileInputStream(file);
			reader = new BufferedReader(new InputStreamReader(in));
		} catch(IOException e) {
			System.err.println("Exception: " + e);
		}
*/
               try {
			file_index = 0;
			filename = _filename.split(":");
			current_file = filename[0];
			File file = new File(current_file);
			System.out.println("Load " + current_file);
			FileInputStream in = new FileInputStream(file);
			reader = new BufferedReader(new InputStreamReader(in));
			hash_key = new HashMap<String,Long>();
			current_key = 0;
                        thread_index=0;

                        File file_ramsize = new File("./ramsize.txt");
			FileInputStream in_ramsize = new FileInputStream(file_ramsize);
			reader_ramsize = new BufferedReader(new InputStreamReader(in_ramsize));
			//update_ramsize();

		} catch(IOException e) {
			System.err.println("Exception: " + e);
		}

	}

	/**
	 * Return the next string of the sequence, ie the next line of the file.
	 */
	public synchronized String nextString()
	{
		try {
		//	return current = reader.readLine();

                    current = reader.readLine();
                    if (current!=null)
                    {
			if (hash_key.containsKey(current))
				return hash_key.get(current).toString();
			else
			{
				current_key++;
				hash_key.put(current, current_key);
				return new Long(current_key).toString();
			}
                    }
                    else
                        return null;
		} catch(NullPointerException e) {
			System.err.println("NullPointerException: " + filename + ':' + current);
			throw e;
		} catch(IOException e) {
			System.err.println("Exception: " + e);
			return null;
		}
	}

	/**
	 * Return the previous read line.
	 */
	public String lastString()
	{
	//	return current;
                return hash_key.get(current).toString();
	}

	/**
	 * Reopen the file to reuse values.
	 */
	public synchronized void reloadFile()
	{
/*		try {
			System.err.println("Reload " + filename);
			reader.close();
			File file = new File(filename);
			FileInputStream in = new FileInputStream(file);
			reader = new BufferedReader(new InputStreamReader(in));
		} catch(IOException e) {
			System.err.println("Exception: " + e);
		}
*/
             thread_index++;
             if (thread_index==1)
             {
                try {			
                //        update_ramsize();
			file_index++;

                        System.out.println("---------------"+file_index+"------------"+filename.length);
			if (file_index==filename.length)
			{
                        	file_index = 0;
                                System.exit(0);
                        }
			current_file = filename[file_index];
			System.out.println("Reload " + current_file);
			reader.close();
			File file = new File(current_file);
			FileInputStream in = new FileInputStream(file);
			reader = new BufferedReader(new InputStreamReader(in));
		} catch(IOException e) {
			System.err.println("Exception: " + e);
		}
               }
               else
               {
                   if (thread_index==Client.threadcount)
                       thread_index = 0;
               }

	}

    public void update_ramsize()
	{
		try {
			ramsize = Integer.valueOf(reader_ramsize.readLine());
                        System.out.println("--------------trying to set ram size = "+ramsize+" -----------");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new Thread() 
		{
			@SuppressWarnings("resource")
			public void run() {
				try {
					Socket clientSocket = new Socket("10.4.128.2", 5001); 
					DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
					BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
					outToServer.write(new Integer(ramsize).byteValue());
					inFromServer.readLine();
			//		if (!inFromServer.readLine().equalsIgnoreCase("done"))
			//		{
			//			System.out.println("---------setting ram size unsuccessfully-----------------");
			//			clientSocket.close();
			//			System.exit(-1);
			//		}
					clientSocket.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				
			}			
		}.start();

	}
}
